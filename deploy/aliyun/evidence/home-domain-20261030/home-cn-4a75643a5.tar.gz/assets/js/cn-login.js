location.replace("https://app.boardx.com.cn/login" + location.search + location.hash);
